import java.util.*;
import java.util.stream.Collectors;

public class ChainblockImpl implements Chainblock{
private Map<Integer, TransactionImpl> dataBase;

    public ChainblockImpl() {
        this.dataBase = new LinkedHashMap<>();
    }

    public int getCount() {
        return dataBase.size();
    }

    public void add(Transaction transaction) {
        TransactionImpl trans = (TransactionImpl) transaction;
        if (!contains(transaction)){
            dataBase.putIfAbsent(trans.getId(), trans);
        }
    }

    public boolean contains(Transaction transaction) {
        TransactionImpl trans = (TransactionImpl) transaction;
        for (int integer : dataBase.keySet()) {
            if (trans.getId() == integer){
                return true;
            }
        }
        return false;
    }

    public boolean contains(int id) {
        for (int integer : dataBase.keySet()) {
            if (integer == id){
                return true;
            }
        }
        return false;
    }

    public void changeTransactionStatus(int id, TransactionStatus newStatus) {
//•	changeTransactionStatus(id, status) – changes the status of the transaction with the given id or throws IllegalArgumentException if no such transaction exists.
        checkDataContainsTransactionById(id);
        try{
            dataBase.get(id).setStatus(newStatus);
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }


    public void removeTransactionById(int id) {
//remove the transaction from the record if the id exists, otherwise throws IllegalArgumentException
        checkDataContainsTransactionById(id);
        dataBase.remove(id);
    }

    public Transaction getById(int id) {
        checkDataContainsTransactionById(id);
        return dataBase.get(id);
    }

    public Iterable<Transaction> getByTransactionStatus(TransactionStatus status) {
        //return the transactions with the given status ordered by amount descending. If there are no transactions with the given status,
        //throw IllegalArgumentException
        if (isNoTransactionWithStatus(status)){
            throw new IllegalArgumentException();
        }
        return dataBase.values().stream()
                .filter(t -> t.getStatus().equals(status))
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public Iterable<String> getAllSendersWithTransactionStatus(TransactionStatus status) {
        if (dataBase.isEmpty()){
            throw new IllegalArgumentException();
        }
        List<String> iterable = new ArrayList<>();
        for (TransactionImpl value : dataBase.values()) {
            if (value.getStatus().equals(status)){
                iterable.add(value.getFrom());
            }
        }
       return iterable;
    }

    public Iterable<String> getAllReceiversWithTransactionStatus(TransactionStatus status) {
        if (dataBase.isEmpty()){
            throw new IllegalArgumentException();
        }
        List<String> iterable = new ArrayList<>();
        for (TransactionImpl value : dataBase.values()) {
            if (value.getStatus().equals(status)){
                iterable.add(value.getTo());
            }
        }
        return iterable;
    }

    public Iterable<Transaction> getAllOrderedByAmountDescendingThenById() {
        if (dataBase.isEmpty()){
            throw new IllegalArgumentException();
        }
      return dataBase.values().stream()
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .sorted(Comparator.comparing(TransactionImpl::getId))
                .collect(Collectors.toList());
    }

    public Iterable<Transaction> getBySenderOrderedByAmountDescending(String sender) {
        // search for all transactions with a specific sender and return them ordered by amount descending.
        // If there are no such transactions throw IllegalArgumentException
         if (!searchTransactionBySender(sender)){
             throw new IllegalArgumentException();
         }

         List<TransactionImpl> transactions = new ArrayList<>();
        for (TransactionImpl value : dataBase.values()) {
            if (value.getFrom().equals(sender)){
                transactions.add(value);
            }
        }

         return transactions.stream().sorted(Comparator.comparing(TransactionImpl::getAmount).reversed()).collect(Collectors.toList());
    }

// returns all transactions with particular receiver ordered by amount descending, then by id ascending.
// If there are no such transactions throw IllegalArgumentException
    public Iterable<Transaction> getByReceiverOrderedByAmountThenById(String receiver) {
        if (!containsReceiver(receiver)){
            throw new IllegalArgumentException();
        }
        return dataBase.values().stream()
                .filter(p -> p.getTo().equals(receiver))
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .sorted(Comparator.comparing(TransactionImpl::getId))
                .collect(Collectors.toList());
    }

    public Iterable<Transaction> getByTransactionStatusAndMaximumAmount(TransactionStatus status, double amount) {
        if (isNoTransactionWithStatus(status)){
            return new ArrayList<>();
        }
        return dataBase.values().stream()
                .filter(p -> p.getAmount()<=amount)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .collect(Collectors.toList());
    }

    public Iterable<Transaction> getBySenderAndMinimumAmountDescending(String sender, double amount) {
        if(!searchTransactionBySender(sender)){
            throw new IllegalArgumentException();
        }
        return dataBase.values().stream()
                .filter(p -> p.getAmount()>amount)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .collect(Collectors.toList());
    }
//returns all transactions with given receiver and amount between lo (inclusive) and hi (exclusive)
// ordered by amount descending then by id. If there are no such transactions throw IllegalArgumentException
    public Iterable<Transaction> getByReceiverAndAmountRange(String receiver, double lo, double hi) {
        List<TransactionImpl> transactions = dataBase.values().stream()
                .filter(p -> p.getTo().equals(receiver))
                .filter(p -> p.getAmount()> lo && p.getAmount()<hi)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .sorted(Comparator.comparing(TransactionImpl::getId))
                .collect(Collectors.toList());
        if (transactions.isEmpty()){
            throw new IllegalArgumentException();
        }
        return new ArrayList<>(transactions);
    }

    public Iterable<Transaction> getAllInAmountRange(double lo, double hi) {
        List<TransactionImpl> result = dataBase.values().stream()
                .filter(p -> p.getAmount() > lo && p.getAmount() < hi)
                .collect(Collectors.toList());
        if (result.isEmpty()){
            return new ArrayList<>();
        }
        return new ArrayList<>(result);
    }

    public Iterator<Transaction> iterator() {
        return new Iterator<Transaction>() {
            int index = 0;
            List<TransactionImpl> transactions  = new ArrayList<>(dataBase.values());
            @Override
            public boolean hasNext() {
                return index<dataBase.size();
            }

            @Override
            public Transaction next() {
                return transactions.get(index++);
            }
        };
    }



    private boolean containsReceiver(String receiver) {
        for (TransactionImpl value : dataBase.values()) {
            if (value.getTo().equals(receiver)){
                return true;
            }
        }
        return false;
    }

    private boolean searchTransactionBySender(String sender) {
        for (TransactionImpl value : dataBase.values()) {
            if (value.getFrom().equals(sender)){
                return true;
            }
        }
        return false;
    }

    private void checkDataContainsTransactionById(int id){
        if (!contains(id)){
            throw new IllegalArgumentException();
        }
    }

    private boolean isNoTransactionWithStatus(TransactionStatus status) {
        for (TransactionImpl transaction : dataBase.values()) {
            if (transaction.getStatus().equals(status)){
                return false;
            }
        }
        return true;
    }
}
