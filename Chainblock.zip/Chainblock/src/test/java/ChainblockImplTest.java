import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

public class ChainblockImplTest {
    private Chainblock chainblock;
    private List<TransactionImpl> transactions;

    public ChainblockImplTest(){
        this.chainblock = new ChainblockImpl();
        this.transactions = new ArrayList<>();
    }

    @Test
    public void Test_AddShouldWorkProperlyWhenAddingNonContainedTransaction(){
        //Transaction
        //Collection.add(transaction)
        //assertTrue(collection.size, 1)
        addingTransactionsToChainBlockAndTransactions(2);
        assertEquals(2, chainblock.getCount());
    }

    @Test
    public void Test_AddShouldWorkProperlyWhenAddingContainedTransaction(){
        Test_AddShouldWorkProperlyWhenAddingNonContainedTransaction();
    }

    @Test
    public void Test_ContainsMethodShouldWorkProperlyWhenAskingForNonExistingId(){
        addingTransactionsToChainBlockAndTransactions(2);
        boolean actual = chainblock.contains(3);
        assertFalse(actual);
    }

    @Test
    public void Test_ContainsMethodShouldWorkProperlyWhenAskingForExistingId(){
        addingTransactionsToChainBlockAndTransactions(3);
        boolean actual = chainblock.contains(2);
        assertTrue(actual);
    }

    @Test
    public void Test_ChangeTransactionStatusWithExistingEnumForTransactionStatus(){
        addingTransactionsToChainBlockAndTransactions(3);
        chainblock.changeTransactionStatus(1, TransactionStatus.ABORTED);
        TransactionImpl transaction =(TransactionImpl) chainblock.getById(1);
        assertEquals(transaction.getStatus(), TransactionStatus.ABORTED);
    }


    @Test(expected = IllegalArgumentException.class)
    public void Test_ChangeTransactionStatusWithNonExistingEnumForTransactionStatus(){
        addingTransactionsToChainBlockAndTransactions(2);
        TransactionStatus status = TransactionStatus.valueOf("Four");
        chainblock.changeTransactionStatus(1, status );
        TransactionImpl transaction =(TransactionImpl) chainblock.getById(1);
    }

    @Test
    public void Test_RemoveTransactionByExistingId(){
        addingTransactionsToChainBlockAndTransactions(2);
        chainblock.removeTransactionById(1);
        assertEquals(1,chainblock.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_RemoveTransactionByNonExistingId(){
        addingTransactionsToChainBlockAndTransactions(5);
        chainblock.removeTransactionById(13);
    }


    @Test(expected = IllegalArgumentException.class)
    public void Test_GetByTransactionStatusShouldThrowException(){
        addingTransactionsToChainBlockAndTransactions(3);
        TransactionStatus status = TransactionStatus.valueOf("Four");
        Iterable<Transaction> byTransactionStatus = chainblock.getByTransactionStatus(status);
    }

    @Test
    public void Test_GetByTransactionsStatusShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(10);
        Iterable<Transaction> transactions = chainblock.getByTransactionStatus(TransactionStatus.FAILED);

        for (Transaction transaction : transactions) {
            TransactionImpl transaction1 = (TransactionImpl) transaction;
            assertEquals(TransactionStatus.FAILED, transaction1.getStatus());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetAllSendersWithTransactionStatusShouldThrowException(){
        Iterable<String> list = chainblock.getAllSendersWithTransactionStatus(TransactionStatus.SUCCESSFUL);
    }

    @Test
    public void Test_GetAllSendersWithTransactionStatusShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(8);
        Iterable<String> actual1 = chainblock.getAllSendersWithTransactionStatus(TransactionStatus.SUCCESSFUL);

        List<String> actual = new ArrayList<>((Collection<? extends String>) actual1);
        List<String> expected = new ArrayList<>();

        for (TransactionImpl transaction : transactions) {
            if (transaction.getStatus().equals(TransactionStatus.SUCCESSFUL)){
                expected.add(transaction.getFrom());
            }
        }
        assertEqualsArrayS(actual, expected);
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetAllRecieversWithTransactionStatusShouldThrowException(){
        Iterable<String> list = chainblock.getAllReceiversWithTransactionStatus(TransactionStatus.SUCCESSFUL);
    }

    @Test
    public void Test_GetAllRecieversWithTransactionStatusShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(8);
        Iterable<String> actual1 = chainblock.getAllReceiversWithTransactionStatus(TransactionStatus.SUCCESSFUL);

        List<String> actual = new ArrayList<>((Collection<? extends String>) actual1);
        List<String> expected = new ArrayList<>();

        for (TransactionImpl transaction : transactions) {
            if (transaction.getStatus().equals(TransactionStatus.SUCCESSFUL)){
                expected.add(transaction.getTo());
            }
        }
        assertEqualsArrayS(actual, expected);
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetAllOrderedByAmountDescendingThenByIdShouldntWorkProperly(){
        Iterable<Transaction> list = chainblock.getAllOrderedByAmountDescendingThenById();
    }

    @Test
    public void Test_GetAllOrderedByAmountDescendingThenByIdShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(15);

        Iterable<Transaction> actual1 = chainblock.getAllOrderedByAmountDescendingThenById();

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = new ArrayList<>(transactions.stream().sorted(Comparator.comparing(TransactionImpl::getAmount)).sorted(Comparator.comparing(TransactionImpl::getId)).collect(Collectors.toList()));

        assertEqualsArrayS(expected, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetBySenderOrderedByAmountDescendingShouldntWorkProperly(){
        Iterable<Transaction> ganio = chainblock.getBySenderOrderedByAmountDescending("Ganio");
    }

    @Test
    public void Test_GetBySenderOrderedByAmountDescendingShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(15);
        Iterable<Transaction> actual1 = chainblock.getBySenderOrderedByAmountDescending("Onzi");

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream().filter(p -> p.getFrom().equals("Onzi")).sorted(Comparator.comparing(TransactionImpl::getAmount).reversed()).collect(Collectors.toList());

        assertEqualsArrayS(expected, actual);

    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetByReceiverOrderedByAmountThenByIdShouldntWorkProperly(){
        Iterable<Transaction> peio = chainblock.getByReceiverOrderedByAmountThenById("Peio");
    }

    @Test
    public void Test_GetByReceiverOrderedByAmountThenByIdShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(8);

        Iterable<Transaction> actual1 = chainblock.getByReceiverOrderedByAmountThenById("Gosho");

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream().filter(p -> p.getTo().equals("Gosho")).sorted(Comparator.comparing(TransactionImpl::getAmount).reversed()).sorted(Comparator.comparing(TransactionImpl::getId)).collect(Collectors.toList());

        assertEqualsArrayS(actual, expected);
    }

    @Test
    public void Test_GetByTransactionStatusAndMaximumAmountShouldReturnEmptyCollection(){
        Iterable<Transaction> v = chainblock.getByTransactionStatusAndMaximumAmount(TransactionStatus.FAILED, 12);
        assertEquals(new ArrayList<>(), v);
    }

    @Test
    public void Test_GetByTransactionStatusAndMaximumAmountShouldReturnCollectionOfTransactionsAndWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(15);

        Iterable<Transaction> actual1 = chainblock.getByTransactionStatusAndMaximumAmount(TransactionStatus.UNAUTHORIZED, 60);

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream().filter(p -> p.getAmount() <= 60)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .collect(Collectors.toList());

        assertEqualsArrayS(expected, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetBySenderAndMinimumAmountDescendingShouldThrowException(){
        Iterable<Transaction> ot = chainblock.getBySenderAndMinimumAmountDescending("OT", 20);
    }

    @Test
    public void Test_GetBySenderAndMinimumAmountDescendingShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(7);

        Iterable<Transaction> actual1 = chainblock.getBySenderAndMinimumAmountDescending("Onzi", 60);

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream().filter(p -> p.getAmount() > 60)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .collect(Collectors.toList());

        assertEqualsArrayS(expected, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void Test_GetByReceiverAndAmountRangeShouldThrowException(){
        Iterable<Transaction> c = chainblock.getByReceiverAndAmountRange("c", 14, 15);
    }

    @Test
    public void Test_GetByReceiverAndAmountRangeShouldWorkProperly(){
        addingTransactionsToChainBlockAndTransactions(15);
        Iterable<Transaction> actual1 = chainblock.getByReceiverAndAmountRange("stamat", 51, 65);

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream()
                .filter(p -> p.getTo().equals("stamat"))
                .filter(p -> p.getAmount() > 51 && p.getAmount() < 65)
                .sorted(Comparator.comparing(TransactionImpl::getAmount).reversed())
                .sorted(Comparator.comparing(TransactionImpl::getId))
                .collect(Collectors.toList());

        assertEqualsArrayS(expected, actual);
    }

    @Test
    public void Test_getAllInAmountRangeShouldReturnEmptyCollection(){
        assertEquals(new ArrayList<>(), chainblock.getAllInAmountRange(12,13));
    }

    @Test
    public void Test_getAllInAmountRangeShouldReturnCollection(){
        addingTransactionsToChainBlockAndTransactions(16);

        Iterable<Transaction> actual1 = chainblock.getAllInAmountRange(57, 60);

        List<TransactionImpl> actual = new ArrayList<TransactionImpl>((ArrayList) actual1);
        List<TransactionImpl> expected = transactions.stream()
                .filter(p -> p.getAmount() > 57 && p.getAmount() < 60)
                .collect(Collectors.toList());

        assertEqualsArrayS(actual, expected);
    }


    private<T> void assertEqualsArrayS(List<T> actual, List<T> expected) {
        for (int i = 0; i < expected.size(); i++) {
            assertEquals(expected.get(i), actual.get(i));
        }
    }

    private void addingTransactionsToChainBlockAndTransactions(int count) {

        for (int i = 0; i < count; i++) {
            Transaction transaction ;
            if (i%2==0 && i !=0){
                transaction = (Transaction) new TransactionImpl(i+1, TransactionStatus.SUCCESSFUL, "Onzi" , "Gosho", 100.0/2 + i);
            }else if (i % 3==0 && i !=0){
                transaction = (Transaction) new TransactionImpl(i+1, TransactionStatus.ABORTED, "Pesho" , "Trolincho", 100.0/2 + i);
            }else if (i % 5==0 && i !=0){
                transaction = (Transaction) new TransactionImpl(i+1, TransactionStatus.FAILED, "Tosho" , "Petkan", 100.0/2 + i);
            }else {
                transaction = (Transaction) new TransactionImpl(i+1, TransactionStatus.UNAUTHORIZED, "Ganio" , "stamat", 100.0/2 + i);
            }
            transactions.add((TransactionImpl) transaction);
            chainblock.add(transaction);
        }

    }
}